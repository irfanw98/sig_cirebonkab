

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/frontend/statistik/penduduk/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="penduduk">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="gradPenduduk">
                    </div>
                    <div class="card-body penduduk-content">
                        <h5>PENDUDUK<br><span>Population</span></h5><br>
                        <p class="title">Penduduk, Laju Pertumbuhan Penduduk, Distribusi Persentase Penduduk, Kepadatan Penduduk, Rasio Jenis Kelamin Menurut Desa/Kelurahan <?php echo e($desa->nama_desa); ?>  di Kecamatan <?php echo e($desa->kecamatan->nama_kecamatan); ?> Kabupaten Cirebon</p>
                        <div class="row justify-content-around mt-5">
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Penduduk (jiwa)<sup>1</sup></p>
                              <canvas id="chartPenduduk"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Laju Pertumbuhan Penduduk per Tahun</p>
                              <canvas id="chartLajuPenduduk"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Persentase Penduduk</p>
                              <canvas id="chartPersentasePenduduk"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Kepadatan Penduduk (per km<sup>2</sup>)<sup>4</sup></p>
                              <canvas id="chartKepadatanPenduduk"></canvas>
                            </div>
                            <div class="col-md-12 col-lg-12 mt-3">
                              <p class="mt-3">Rasio Jenis Kelamin</p>
                              <canvas id="chartRasioJk"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

const penduduk = document.getElementById('chartPenduduk');
const chartPenduduk = new Chart(penduduk, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($penduduk->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Jiwa',
            data: [
              <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($penduduk->jumlah); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(95, 150, 198, 0.2)',
            ],
            borderColor: [
                'rgba(95, 150, 198, 1',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

//Laju Pertumbuhan Penduduk
const lajuPenduduk = document.getElementById('chartLajuPenduduk');
const chartLajuPenduduk = new Chart(lajuPenduduk, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($penduduk->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Laju Pertumbuhan',
            data: [
              <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($penduduk->laju); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(95, 150, 198, 0.2)',
            ],
            borderColor: [
                'rgba(95, 150, 198, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

//Persentase Penduduk
const persentasePenduduk = document.getElementById('chartPersentasePenduduk');
const chartPersentasePenduduk = new Chart(persentasePenduduk, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($penduduk->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Persentase',
            data: [
              <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($penduduk->persentase); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(95, 150, 198, 0.2)',
            ],
            borderColor: [
                'rgba(95, 150, 198, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

//Kepadatan Penduduk
const kepadatanPenduduk = document.getElementById('chartKepadatanPenduduk');
const chartKepadatanPenduduk = new Chart(kepadatanPenduduk, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($penduduk->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Kepadatan',
            data: [
              <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($penduduk->kepadatan); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(95, 150, 198, 0.2)',
            ],
            borderColor: [
                'rgba(95, 150, 198, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

//Kepadatan Penduduk
const rasioJenisKelamin = document.getElementById('chartRasioJk');
const chartRasioJk = new Chart(rasioJenisKelamin, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($penduduk->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Rasio',
            data: [
              <?php $__currentLoopData = $penduduks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penduduk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($penduduk->rasio_jk); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(95, 150, 198, 0.2)',
            ],
            borderColor: [
                'rgba(95, 150, 198, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/penduduk.blade.php ENDPATH**/ ?>