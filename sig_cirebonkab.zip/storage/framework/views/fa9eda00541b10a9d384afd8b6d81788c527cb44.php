<form action="" method="post" autocomplete="off" class="formEditGaram">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">

            <input type="hidden" name="id" id="id" value="<?php echo e($garam->id); ?>">

            <div class="form-group">
                <label for="kode_kecamatan">Kecamatan :</label>
                <select class="select2multiple form-control" name="kode_kecamatan" id="kode_kecamatan">
                    <option value="">-- Pilih Kecamatan --</option>
                    <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kecamatan->kode_kecamatan); ?>" <?php if($garam->kecamatan->kode_kecamatan == $kecamatan->kode_kecamatan): ?> selected <?php endif; ?>><?php echo e($kecamatan->nama_kecamatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <span class="text-danger" id="kode_kecamatanError"></span>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="tahun">Tahun :</label>
                <input type="text" class="form-control" id="tahun" name="tahun" value="<?php echo e($garam->tahun); ?>">

                <span class="text-danger" id="tahunError"></span>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6 col-lg-6">
           <div class="form-group">
                <label for="uraian">Uraian :</label>
                <select class="select2multiple form-control" name="uraian" id="uraian">
                    <option value="">-- Pilih Uraian --</option>
                    <option value="Petambak (Orang) / Salt Farmers (People)" <?php if($garam->uraian == 'Petambak (Orang) / Salt Farmers (People)'): ?> selected <?php endif; ?>>Petambak (Orang) / Salt Farmers (People)</option>
                    <option value="Luas Lahan (ha) / Land Area (ha)" <?php if($garam->uraian == 'Luas Lahan (ha) / Land Area (ha)'): ?> selected <?php endif; ?>>Luas Lahan (ha) / Land Area (ha)</option>
                    <option value="Produksi (ton) / Production (ton)" <?php if($garam->uraian == 'Produksi (ton) / Production (ton)'): ?> selected <?php endif; ?>>Produksi (ton) / Production (ton)</option>
                </select>

                <span class="text-danger" id="uraianError"></span>
            </div>
        </div>
        <div class="col-md-6 col-lg-6">
            <div class="form-group">
                <label for="jumlah">Jumlah :</label>
                <input type="text" class="form-control" id="jumlah" name="jumlah" value="<?php echo e($garam->jumlah); ?>">

                <span class="text-danger" id="jumlahError"></span>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary editButtonGaram">Simpan</button>
        <button type="button" class="btn btn-outline-danger cancelButtonGaram" data-dismiss="modal">Batal</button>
    </div>
</form>

<script type="text/javascript">
    $(document).ready(function() {
        $('.select2multiple').select2();
    })
</script><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/statistik/garam/edit.blade.php ENDPATH**/ ?>