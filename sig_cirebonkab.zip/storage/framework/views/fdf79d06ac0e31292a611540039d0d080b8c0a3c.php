

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/frontend/statistik/geografi/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="geografi">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="gradGeografi">
                    </div>
                    <div class="card-body geografi-content">
                        <h5>GEOGRAFI<br><span>Geography</span></h5><br>
                        <p class="title">Luas Daerah Menurut Desa <?php echo e($desa->nama_desa); ?> dan Ketinggian di Kecamatan <?php echo e($desa->kecamatan->nama_kecamatan); ?> Kabupaten Cirebon</p>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-6 col-lg-5 mb-4">
                              <p class="mt-3">Luas (Km<sup>2</sup>)</p>
                                <canvas id="chartLuas"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-5">
                              <p class="mt-3">Ketinggian (m)</p>
                              <canvas id="chartKetinggian"></canvas>
                            </div>
                        </div>
                        <p class="title">Jarak Dari Desa <?php echo e($desa->nama_desa); ?> Ke Kabupaten dan Kecamatan Serta Jarak Antar Desa di Kecamatan <?php echo e($desa->kecamatan->nama_kecamatan); ?> Kabupaten Cirebon</p>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-6 col-lg-5 mb-5">
                              <p class="mt-3">Jarak Kecamatan (Km)</p>
                              <canvas id="chartJarakKecamatan"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-5">
                              <p class="mt-3">Jarak Kabupaten (m)</p>
                              <canvas id="chartJarakKabupaten"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
//=====================================================GEOGRAFI=======================================//

//Luas
const luas = document.getElementById('chartLuas');
const chartLuas = new Chart(luas, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($geografi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Luas (Km)',
            data: [
              <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($geografi->luas); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
          y: {
            ticks: {
              beginAtZero: true,
            },
          },
        },
      }
});


//Ketinnggian
const ketinggian = document.getElementById('chartKetinggian');
const chartKetinggian = new Chart(ketinggian, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($geografi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Ketinggian (m)',
            data: [
              <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($geografi->ketinggian); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
          y: {
            ticks: {
              stepSize: 1,
              beginAtZero: true,
            },
          },
        },
      }
});


//Jarak Kecamatan
const jarakKecamatan = document.getElementById('chartJarakKecamatan');
const chartJarakKecamatan = new Chart(jarakKecamatan, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($geografi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Jarak Kecamatan (Km)',
            data: [
              <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($geografi->jarak_kecamatan); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
          y: {
            ticks: {
              beginAtZero: true,
            },
          },
        },
      }
});


//Jarak Kabupaten
const jarakKabupaten = document.getElementById('chartJarakKabupaten');
const chartJarakKabupaten = new Chart(jarakKabupaten, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($geografi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Jarak Kabupaten (Km)',
            data: [
              <?php $__currentLoopData = $geografis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $geografi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($geografi->jarak_kabupaten); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
          y: {
            ticks: {
              beginAtZero: true,
            },
          },
        },
      }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/geografi.blade.php ENDPATH**/ ?>