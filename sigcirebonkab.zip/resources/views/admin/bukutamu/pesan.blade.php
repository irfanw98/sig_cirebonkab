<div class="row">
 <div class="col-lg-12">
    <p>{{ $buku_tamu->pesan }}</p>
 </div>
</div>
<div class="row">
    <div class="col-lg-12 ">
        <div class="d-flex align-items-end flex-column bd-highlight mb-3">
            <div class="p-2 bd-highlight">
                <button type="button" class="btn btn-outline-danger" data-dismiss="modal"><i class="fa fa-window-close"></i> Tutup</button>
            </div>
        </div>
    </div>
</div>