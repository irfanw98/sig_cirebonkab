

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/frontend/statistik/energi/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="energi">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="gradEnergi">
                    </div>
                    <div class="card-body energi-content">
                        <h5>ENERGI<br><span>Energy</span></h5><br>
                        <p class="title">Banyak Keluarga Menurut Desa/Kelurahan <?php echo e($desa->nama_desa); ?> dan Jenis Pengguna Listrik di Kecamatan <?php echo e($desa->kecamatan->nama_kecamatan); ?> Kabupaten Cirebon</p>
                        <p class="title">Pengguna Listrik</p>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">PLN</p>
                              <canvas id="chartPln"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Non PLN</p>
                              <canvas id="chartNonPln"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Jumlah</p>
                              <canvas id="chartJumlahPln"></canvas>
                            </div>
                        </div>
                        <div class="row justify-content-center mt-3 mb-5">
                            <div class="col-md-12 col-lg-12 mt-2">
                                <p class="title mt-3">Bukan Pengguna Listrik</p>
                                <canvas id="chartNonListik"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
//=============================================ENERGI===================================//

//PLN
const pln = document.getElementById('chartPln');
const chartPln = new Chart(pln, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($energi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($energi->pln); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(255, 248, 0, 0.2)',
            ],
            borderColor: [
                'rgba(255, 248, 0, 1)',
            ],
            borderWidth: 1
        }]
    },
   options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

//NON PLN
const nonPln = document.getElementById('chartNonPln');
const chartNonPln = new Chart(nonPln, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($energi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($energi->non_pln); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(255, 248, 0, 0.2)',
            ],
            borderColor: [
                'rgba(255, 248, 0, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

//JUMLAH PLN
const jumlahPln = document.getElementById('chartJumlahPln');
const chartJumlahPln = new Chart(jumlahPln, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($energi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($energi->pln_jumlah); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(255, 248, 0, 0.2)',
            ],
            borderColor: [
                'rgba(255, 248, 0, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

//NON LISTRIK
const nonListrik = document.getElementById('chartNonListik');
const chartNonListik = new Chart(nonListrik, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($energi->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $energis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($energi->non_listrik); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(255, 248, 0, 0.2)',
            ],
            borderColor: [
                'rgba(255, 248, 0, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/energi.blade.php ENDPATH**/ ?>