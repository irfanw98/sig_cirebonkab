<form action="" method="post" autocomplete="off" class="formInsertBudidayaperikanan">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">

            <input type="hidden" name="id" id="id">

            <div class="form-group">
                <label for="kode_kecamatan">Kecamatan :</label>
                <select class="select2multiple form-control" name="kode_kecamatan" id="kode_kecamatan">
                    <option value="">-- Pilih Kecamatan --</option>
                    <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kecamatan->kode_kecamatan); ?>"><?php echo e($kecamatan->nama_kecamatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <span class="text-danger" id="kode_kecamatanError"></span>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="tahun">Tahun :</label>
                <input type="text" class="form-control" id="tahun" name="tahun">

                <span class="text-danger" id="tahunError"></span>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6 col-lg-6">
            <div class="form-group">
                <label for="jenis_budidaya">Jenis Budidaya :</label>
                <select class="select2multiple form-control" name="jenis_budidaya" id="jenis_budidaya">
                    <option value="">-- Pilih Jenis Budidaya --</option>
                    <option value="Budidaya Laut / Marine Culture">Budidaya Laut / Marine Culture</option>
                    <option value="Tambak Brackish / Water Pond">Tambak Brackish / Water Pond</option>
                    <option value="Kolam Fresh / Water Pond">Kolam Fresh / Water Pond</option>
                </select>

                <span class="text-danger" id="uraianError"></span>
            </div>
        </div>
        <div class="col-md-6 col-lg-6">
            <div class="form-group">
                <label for="jumlah_budidaya">Jumlah Budidaya :</label>
                <input type="text" class="form-control" id="jumlah_budidaya" name="jumlah_budidaya">

                <span class="text-danger" id="jumlah_budidayaError"></span>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary saveButtonBudidayaperikanan">Simpan</button>
        <button type="button" class="btn btn-outline-danger cancelButtonBudidayaperikanan" data-dismiss="modal">Batal</button>
    </div>
</form>

<script type="text/javascript">
    $(document).ready(function() {
        $('.select2multiple').select2();
    })
</script><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/statistik/budidayaperikanan/tambah.blade.php ENDPATH**/ ?>