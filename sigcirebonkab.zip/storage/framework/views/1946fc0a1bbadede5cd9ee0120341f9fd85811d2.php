

<?php $__env->startSection('title', 'SIG Kabupaten Cirebon | Statistik - Ubah Password'); ?>

<?php $__env->startSection('header'); ?>
<style>
    .grad {
        background-color: #ffc107;
        height: 4px;
        border-radius: 20px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header-content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-md-6">
                <h3>Ubah Password</h3>
            </div>
            <div class="col-md-6 p-2">
                <ol class="breadcrumb float-sm-right">
                    <ol class="breadcrumb float-sm-right">
                      <li class="breadcrumb-item">
                        <?php if(Auth::user()): ?>
                         <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                        <?php endif; ?>
                      </li>
                      <li class="breadcrumb-item active">Ubah Password</li>
                    </ol>
                </ol>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 table-responsive">
        <div class="card">
            <div class="grad">
            </div>
            <div class="card-body">
            <form action="" method="POST" autocomplete="off" class="border p-3 rounded formPassword">
                <?php echo csrf_field(); ?>
                <div class=" row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="password_lama">Password Lama :</label>
                            <input type="password" name="password_lama" id="password_lama" class="form-control" placeholder="Masukkan Password Lama">

                            <span class="text-danger" id="password_lamaErr"></span>
                        </div>
                        <div class="form-group">
                            <label for="password">Password Baru :</label>
                            <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password Baru">

                            <span class="text-danger" id="passwordErr"></span>
                        </div>
                        <div class="form-group">
                            <label for="password_confirmation">Konfirmasi Password Baru :</label>
                            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="Konfirmasi Password Baru">

                            <span class="text-danger" id="password_confirmationErr"></span>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary ubahPassword">Simpan</button>
            </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(document).on('click', '.ubahPassword', function(e) {
    e.preventDefault()
    let form = $('.formPassword')[0]
    const formData = new FormData(form)

    //Validasi form input
    $('#password_lamaErr').addClass('d-none')
    $('#passwordErr').addClass('d-none')
    $('#password_confirmationErr').addClass('d-none')

    $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "<?php echo e(url('/ubah-password')); ?>",
        method: "POST",
        data: formData,
        contentType: false,
        processData: false,
        cache: false,
        success: function(response) {         
            // Swal.fire({
            //     position: 'center',
            //     icon: 'success',
            //     title: 'Password berhasil Diubah!',
            //     showConfirmButton: false,
            //     timer: 1500
            // })

            // $('#password_lama').removeClass('is-invalid');
            // $('#password').removeClass('is-invalid');
            // $('#password_confirmation').removeClass('is-invalid');

            // $('.formPassword').trigger('reset');//Reset inputan form
        },
        error: function(data) {
            // let errors = data.responseJSON;
            // if ($.isEmptyObject(errors) == false) {
            //     $.each(errors.errors, function(key,value) {
            //         let errID = '#' + key + 'Err';
            //         $('#password_lama').removeClass('is-valid');
            //         $('#password_lama').addClass('is-invalid');
            //         $('#password').removeClass('is-valid');
            //         $('#password').addClass('is-invalid');
            //         $('#password_confirmation').removeClass('is-valid');
            //         $('#password_confirmation').addClass('is-invalid');
            //         $(errID).removeClass('d-none');
            //         $(errID).text(value);
            //     })
            // } 
        }
    })
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/password/index.blade.php ENDPATH**/ ?>