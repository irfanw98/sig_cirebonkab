

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/frontend/tentangkami/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="tentangkami">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <?php $__currentLoopData = $tentangkamis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tentangkami): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3>Kabupaten Cirebon</h3>
                            <img src="<?php echo e(asset('storage/tentangkami')); ?>/<?php echo e($tentangkami->foto); ?>" alt="kantor-bupati">
                            <p><?php echo $tentangkami->deskripsi; ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/tentangkami.blade.php ENDPATH**/ ?>