

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/frontend/bukutamu/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="bukutamu">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="grad">
                    </div>
                    <div class="card-body">
                        <div class="row justify-content-around">
                            <div class="col-sm-6 col-md-6 col-lg-5 align-items-center img-bukutamu">
                                <div class="bukutamu__img">
                                    <img src="<?php echo e(asset('img/bukutamu.svg')); ?>" class="img-fluid" alt="bukutamu-img">
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-6 col-lg-6 bukutamu-form">
                                <form action="" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <label for="nama_lengkap">Nama Lengkap</label>
                                        <input type="text" id="nama_lengkap" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" id="email" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="nomor_tlp">Nomor Telepon</label>
                                        <input type="text" id="nomor_tlp" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <label for="pesan">Pesan</label>
                                        <textarea id="pesan" class="form-control" rows="4"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <a href="" type="btn" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Kirim</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/bukutamu.blade.php ENDPATH**/ ?>