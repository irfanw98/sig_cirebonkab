

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/frontend/statistik/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Konten Statistik -->
<section class="konten-statistik">
  <div class="container">
    <div class="row mt-5">
      <div class="col-md-12 col-lg-12 text-center title">
        <h2>Statistik <span><?php echo e($desa->nama_desa); ?></span></h2>
        <p class="section-line"></p>
      </div>
    </div>
    <div class="row mt-5 mb-5">
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/geografi')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/geografi.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Geografi</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/pemerintahan')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/pemerintahan.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Pemerintahan</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/penduduk')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/penduduk.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Penduduk</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/sosial')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/sosial.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Sosial</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/pertanian')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/pertanian.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Pertanian</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/energi')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/energi.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Energi</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/perdagangan')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/perdagangan.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Perdagangan</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/transportasi')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/transportasi.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Transportasi</h5>
            </div>
          </div>
        </a>
      </div>
      <div class="col-md-6 col-lg-4 statistik">
        <a href="<?php echo e(url('/statistik/keuangan')); ?>/<?php echo e($desa->id_desa); ?>">
          <div class="card sevice-card">
            <div class="service-card__img">
              <img src="<?php echo e(asset('img/keuangan.png')); ?>">
            </div>
            <div class="card-body">
              <h5 class="card-title">Keuangan</h5>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>
<!-- End Konten Statistik -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/statistik.blade.php ENDPATH**/ ?>