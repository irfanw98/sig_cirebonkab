<form action="" method="post" autocomplete="off" class="formEditPerkebunan">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-6">

            <input type="hidden" name="id" id="id" value="<?php echo e($perkebunan->id); ?>">

            <div class="form-group">
                <label for="kode_kecamatan">Kecamatan :</label>
                <select class="select2multiple form-control" name="kode_kecamatan" id="kode_kecamatan">
                    <option value="">-- Pilih Kecamatan --</option>
                    <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kecamatan->kode_kecamatan); ?>" <?php if($perkebunan->kecamatan->kode_kecamatan == $kecamatan->kode_kecamatan): ?> selected <?php endif; ?>><?php echo e($kecamatan->nama_kecamatan); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <span class="text-danger" id="kode_kecamatanError"></span>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                <label for="tahun">Tahun :</label>
                <input type="text" class="form-control" id="tahun" name="tahun" value="<?php echo e($perkebunan->tahun); ?>">

                <span class="text-danger" id="tahunError"></span>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <div class="form-group">
                <label for="jenis_tanaman">Jenis tanaman :</label>
                <select class="select2multiple form-control" name="jenis_tanaman" id="jenis_tanaman">
                    <option value="">-- Pilih Jenis Tanaman --</option>
                    <option value="Kelapa / Coconut" <?php if($perkebunan->jenis_tanaman == 'Kelapa / Coconut'): ?> selected <?php endif; ?>>Kelapa / Coconut</option>
                    <option value="Tebu / Sugar Cane" <?php if($perkebunan->jenis_tanaman == 'Tebu / Sugar Cane'): ?> selected <?php endif; ?>>Tebu / Sugar Cane</option>
                </select>

                <span class="text-danger" id="jenis_tanamanError"></span>
            </div>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6 col-lg-6">
            <div class="form-group">
                <label for="luas_areal">Luas Areal Tanaman (Ha):</label>
                <input type="text" class="form-control" id="luas_areal" name="luas_areal" value="<?php echo e($perkebunan->luas_areal); ?>">

                <span class="text-danger" id="luas_arealError"></span>
            </div>
        </div>
        <div class="col-md-6 col-lg-6">
            <div class="form-group">
                <label for="produksi">Produksi (Ton):</label>
                <input type="text" class="form-control" id="produksi" name="produksi" value="<?php echo e($perkebunan->produksi); ?>">

                <span class="text-danger" id="produksiError"></span>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary editButtonPerkebunan">Simpan</button>
        <button type="button" class="btn btn-outline-danger cancelButtonPerkebunan" data-dismiss="modal">Batal</button>
    </div>
</form>

<script type="text/javascript">
    $(document).ready(function() {
        $('.select2multiple').select2();
    })
</script><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/statistik/perkebunan/edit.blade.php ENDPATH**/ ?>