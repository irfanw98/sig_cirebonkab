<form action="" method="post" autocomplete="off" class="formEditTentangkami" enctype="multipart/form-data">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-md-12 text-center">
            <input type="hidden" name="id_tentang_kami" id="id_tentang_kami" value="<?php echo e($tentangkami->id_tentang_kami); ?>">

            <div class="form-group">
                <img src="<?php echo e(asset('storage/tentangkami')); ?>/<?php echo e($tentangkami->foto); ?>" width="300px"><br>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <div class="form-group">
                <label for="foto">Upload Foto :</label>
                <input type="file" id="foto" name="foto">

                <span class="text-danger" id="fotoError"></span>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="deskripsi">Deskripsi :</label>
                <input id="deskripsi" type="hidden" name="deskripsi" value="<?php echo e($tentangkami->deskripsi); ?>">
                <trix-editor input="deskripsi"></trix-editor>

                <span class="text-danger" id="deskripsiError"></span>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-outline-primary editButtonTentangkami">Simpan</button>
        <button type="button" class="btn btn-outline-danger cancelButtonTentangkami" data-dismiss="modal">Batal</button>
    </div>
</form><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/tentangkami/edit.blade.php ENDPATH**/ ?>