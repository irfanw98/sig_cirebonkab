

<?php $__env->startSection('header'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/frontend/statistik/perdagangan/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="perdagangan">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-lg-12">
                <div class="card">
                    <div class="gradPerdagangan">
                    </div>
                    <div class="card-body perdagangan-content">
                        <h5>PERDAGANGAN<br><span>Trading</span></h5><br>
                        <p class="title">Banyak Sarana Dan Prasarana Ekonomi Menurut Desa/Kelurahan <?php echo e($desa->nama_desa); ?> dan Jenisnya di Kecamatan <?php echo e($desa->kecamatan->nama_kecamatan); ?> Kabupaten Cirebon</p>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Kelompok Pertokoan</p>
                              <canvas id="chartKelPer"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Pasar Dengan Bangunan Permanen</p>
                              <canvas id="chartPbp"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Pasar Dengan Bangunan Semi Permanen</p>
                              <canvas id="chartPbsp"></canvas>
                            </div>
                        </div>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Pasar Tanpa Bangunan</p>
                              <canvas id="chartPtb"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Minimarket/Swalayan</p>
                              <canvas id="chartMinimarket"></canvas>
                            </div>
                            <div class="col-md-4 col-lg-4 mt-3">
                              <p class="mt-3">Toko/Warung Kelontong</p>
                              <canvas id="chartToko"></canvas>
                            </div>
                        </div>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Restoran/Rumah Makan</p>
                              <canvas id="chartRestoran"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Warung/Kedai Makanan</p>
                              <canvas id="chartWarung"></canvas>
                            </div>     
                        </div>
                        <div class="row justify-content-around mt-5 mb-5">
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Hotel</p>
                              <canvas id="chartHotel"></canvas>
                            </div>
                            <div class="col-md-6 col-lg-6 mt-3">
                              <p class="mt-3">Hostel/Motel/Losmen/Wisma</p>
                              <canvas id="chartMotel"></canvas>
                            </div>   
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

const kelompokPertokoan = document.getElementById('chartKelPer');
const chartKelPer = new Chart(kelompokPertokoan, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->kelompok_pertokoan); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const pasarBangunanPermanen = document.getElementById('chartPbp');
const chartPbp = new Chart(pasarBangunanPermanen, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->pasar_bangunan_permanen); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const pasarBangunanSemiPermanen = document.getElementById('chartPbsp');
const chartPbsp = new Chart(pasarBangunanSemiPermanen, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->pasar_bangunan_semipermanen); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const pasarTanpaBangunan = document.getElementById('chartPtb');
const chartPtb = new Chart(pasarTanpaBangunan, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->pasar_tanpa_bangunan); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const miniMarket = document.getElementById('chartMinimarket');
const chartMinimarket = new Chart(miniMarket, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->minimarket); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const toko = document.getElementById('chartToko');
const chartToko = new Chart(toko, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->toko); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const restoran = document.getElementById('chartRestoran');
const chartRestoran = new Chart(restoran, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->restoran); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const warung = document.getElementById('chartWarung');
const chartWarung = new Chart(warung, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->warung); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const hotel = document.getElementById('chartHotel');
const chartHotel = new Chart(hotel, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->hotel); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});

const motel = document.getElementById('chartMotel');
const chartMotel = new Chart(motel, {
    type: 'bar',
    data: {
        labels: [
          <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            '<?php echo e($perdagangan->tahun); ?>',
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ],
        datasets: [{
            label: 'Banyak',
            data: [
              <?php $__currentLoopData = $perdagangans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perdagangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($perdagangan->motel); ?>,
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            backgroundColor: [
                'rgba(160, 5, 45, 0.3)',
            ],
            borderColor: [
                'rgba(160, 5, 45, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
             y: {
                ticks: {
                    stepSize: 1,
                    beginAtZero: true,
                },
            },
        },
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/frontend/perdagangan.blade.php ENDPATH**/ ?>