<div class="row">
 <div class="col-lg-12">
  <table class="table table-bordered table-hover">
   <thead>
    <tr>
        <th>ID Desa</th>
        <td><?php echo e($desa->id_desa); ?></td>
    </tr>
    <tr>
        <th>Kode Desa</th>
        <td><?php echo e($desa->kode_desa); ?></td>
    </tr>
    <tr>
        <th>Nama Desa</th>
        <td><?php echo e($desa->nama_desa); ?></td>
    </tr>
    <tr>
        <th>Kecamatan</th>
        <td><?php echo e($desa->kecamatan->nama_kecamatan); ?></td>
    </tr>
    <tr>
        <th>Foto</th>
        <td>
             <img src="<?php echo e(asset('storage/desa')); ?>/<?php echo e($desa->foto); ?>" width="200px">
        </td>
    </tr>
    <tr>
        <th>Warna Wilayah Desa</th>
        <td style="background-color: <?php echo e($desa->warna_wilayah_desa); ?>"></td>
    </tr>
    <tr>
        <th>Latitude</th>
        <td><?php echo e($desa->latitude); ?></td>
    </tr>
    <tr>
        <th>Longitude</th>
        <td><?php echo e($desa->longitude); ?></td>
    </tr>
    <tr>
        <th>Deskripsi</th>
        <td><?php echo $desa->deskripsi; ?></td>
    </tr>
   </thead>
  </table>
 </div>
</div>
<div class="row">
    <div class="col-lg-12 ">
        <div class="d-flex align-items-end flex-column bd-highlight mb-3">
            <div class="p-2 bd-highlight">
                <button type="button" class="btn btn-outline-danger" data-dismiss="modal"><i class="fa fa-window-close"></i> Tutup</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/admin/desa/detail.blade.php ENDPATH**/ ?>