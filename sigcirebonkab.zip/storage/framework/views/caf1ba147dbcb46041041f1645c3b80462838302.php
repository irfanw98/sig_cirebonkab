<nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-color: #0275d8; color: #fff;">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars" style="color: #fff;"></i></a>
        </li>
    </ul>

    <div class="col-lg-8 col-md-8 col-sm-8 pt-1">
        <ul class="navbar-nav">
            <li class="nav-item mt-2">
                <marquee><h4>Sistem Informasi Geografis Kabupaten Cirebon</h4></marquee>
            </li>
        </ul>
    </div>

     <!-- Right navbar links -->
    <div class="col-lg-3 col-md-3 col-sm-3">
        <ul class="navbar-nav">
            <li class="nav-item ml-auto m-1">
                <a href="<?php echo e(url('/logout')); ?>" class="nav-link btn btn-md btn-warning">
                    <i class="nav-icon fas fa-sign-out-alt" style="color: #fff;"> Logout</i>    
                </a>
            </li>
        </ul>
    </div>
</nav>

<?php /**PATH C:\xampp\htdocs\sig_cirebonkab\resources\views/template/includes/navbar.blade.php ENDPATH**/ ?>